
document.getElementById('root').innerHTML = '<h1>مرحبا بكم في لعبة الأسئلة</h1>';
